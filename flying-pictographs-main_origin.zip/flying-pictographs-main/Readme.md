# This is a photography blog

## Features
- Main idea: photographers can upload their photos like instagram
1. a photographer can make a post
2. post have photo and caption
3. Favourite a photo  they posited

# DB Modeling
- Users/Photographers [user_id,name,....]
- Posts [user_id,image,caption]
- Comments   [post_id,user_id,message]
- Favourites [post_id, user_id]

